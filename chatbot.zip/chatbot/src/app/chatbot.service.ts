import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

export class Message {
  constructor(public author: string, public content: string) {}
}

@Injectable()
export class ChatService {
  constructor() {}
  
  conversation = new Subject<Message[]>();
  
  messageMap:any = {
    "Hi": "Hello, How I can help you?",
    "I need help tracking my order?": "Hello, I can help with that. Could you please provide your order number?",
    "Hello": "Hello, How can i help you?",
    "12345": "Thank You !, I see that your order is on its way and is expected to arrive by Aug 29 2024, Is there anything else I can assist with?",
    "How are you": "I'm good, How are you?",
    "No": "Glad I could help! if you have any more questions. feel free to reach out. Thank you",
    "What is Angular": "Angular is the best framework ever",
    "default": "Sorry... I am not able to understand. Could you please elaborate your question ?"
  }
 
  getBotAnswer(msg: string) {
    const userMessage = new Message('user', msg);  
    this.conversation.next([userMessage]);
    const botMessage = new Message('bot', this.getBotMessage(msg));
    setTimeout(()=>{
      this.conversation.next([botMessage]);
    }, 1500);
  }

  getBotMessage(question: any){
    let answer = this.messageMap[question];
    return answer || this.messageMap["default"];
  }

  multiFilter(array, filters) {
    return array.filter(o =>
    Object.keys(filters).every(k =>
    [].concat(filters[k]).some(v => o[k].includes(v))));
}

}